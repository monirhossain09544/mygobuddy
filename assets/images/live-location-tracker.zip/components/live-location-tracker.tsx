"use client"

import { useEffect, useRef, useState } from "react"
import { useSearchParams } from "next/navigation"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"

// This should be the URL of your deployed Supabase function
const SUPABASE_FUNCTION_URL = "https://rbzgchesdmyychvpplgq.supabase.co/functions/v1/get-shared-location"

export default function LiveLocationTracker() {
  const searchParams = useSearchParams()
  const token = searchParams.get("token")

  const mapContainer = useRef<HTMLDivElement | null>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const marker = useRef<mapboxgl.Marker | null>(null)
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null)

  const [status, setStatus] = useState({ message: "Initializing...", isError: false })
  const [mapboxToken, setMapboxToken] = useState<string | null>(null)
  const [isMapVisible, setIsMapVisible] = useState(true)

  // Effect to fetch the Mapbox token from our secure API route
  useEffect(() => {
    const fetchToken = async () => {
      try {
        const response = await fetch("/api/mapbox-token")
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to fetch Mapbox token")
        }
        const data = await response.json()
        setMapboxToken(data.token)
      } catch (error: any) {
        console.error(error)
        setStatus({ message: `Error: ${error.message}`, isError: true })
        setIsMapVisible(false)
      }
    }
    fetchToken()
  }, [])

  // Effect to initialize the map and fetch location data
  useEffect(() => {
    if (!mapboxToken) {
      return // Wait for the token to be fetched
    }

    if (!token) {
      setStatus({ message: "Error: Share token not found in URL. Please add `?token=...` to the URL.", isError: true })
      setIsMapVisible(false)
      return
    }

    mapboxgl.accessToken = mapboxToken

    if (map.current || !mapContainer.current) return // Initialize map only once

    setStatus({ message: "Fetching location...", isError: false })

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: [0, 0],
      zoom: 1,
    })

    const fetchLocation = async () => {
      try {
        const response = await fetch(`${SUPABASE_FUNCTION_URL}?token=${token}`)
        const data = await response.json()

        if (!response.ok) {
          throw new Error(data.error || `Request failed with status ${response.status}`)
        }

        const { latitude, longitude, updatedAt } = data
        const coordinates: [number, number] = [longitude, latitude]
        const lastUpdated = new Date(updatedAt)

        setStatus({
          message: `Location updated: ${lastUpdated.toLocaleTimeString()}`,
          isError: false,
        })

        if (map.current) {
          if (!marker.current) {
            marker.current = new mapboxgl.Marker().setLngLat(coordinates).addTo(map.current)
            map.current.flyTo({ center: coordinates, zoom: 15 })
          } else {
            marker.current.setLngLat(coordinates)
            map.current.panTo(coordinates)
          }
        }
      } catch (error: any) {
        console.error("Error fetching location:", error)
        setStatus({ message: `Error: ${error.message}`, isError: true })

        const errorMessage = error.message.toLowerCase()
        if (
          errorMessage.includes("expired") ||
          errorMessage.includes("invalid") ||
          errorMessage.includes("token is required")
        ) {
          if (pollingIntervalRef.current) {
            clearInterval(pollingIntervalRef.current)
          }
          setIsMapVisible(false)
        }
      }
    }

    fetchLocation() // Fetch immediately
    pollingIntervalRef.current = setInterval(fetchLocation, 15000) // Poll every 15 seconds

    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current)
      }
      if (map.current) {
        map.current.remove()
        map.current = null
        marker.current = null
      }
    }
  }, [token, mapboxToken])

  return (
    <div className="relative w-screen h-screen bg-gray-50">
      <div
        className={`absolute top-2.5 left-2.5 right-2.5 p-4 rounded-lg shadow-lg z-10 text-center font-sans transition-colors duration-300 ${
          status.isError ? "bg-red-100 text-red-800" : "bg-white text-gray-800"
        }`}
      >
        {status.message}
      </div>
      {isMapVisible && <div ref={mapContainer} className="absolute top-0 bottom-0 w-full h-full" />}
    </div>
  )
}
