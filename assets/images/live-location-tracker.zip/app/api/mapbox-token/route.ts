import { NextResponse } from "next/server"

// This is a Route Handler that runs only on the server.
// It safely exposes your public Mapbox token to the client.
export async function GET() {
  const token = process.env.MAPBOX_ACCESS_TOKEN

  if (!token) {
    return NextResponse.json({ error: "Mapbox token not configured on the server." }, { status: 500 })
  }

  return NextResponse.json({ token })
}
