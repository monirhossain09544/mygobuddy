import { Suspense } from "react"
import LiveLocationTracker from "@/components/live-location-tracker"

function LoadingState() {
  return (
    <div className="relative w-full h-screen bg-gray-100">
      <div className="absolute top-4 left-4 right-4 bg-white p-4 rounded-lg shadow-md z-10 text-center font-sans">
        Initializing Map...
      </div>
    </div>
  )
}

export default function Page() {
  return (
    <Suspense fallback={<LoadingState />}>
      <LiveLocationTracker />
    </Suspense>
  )
}
